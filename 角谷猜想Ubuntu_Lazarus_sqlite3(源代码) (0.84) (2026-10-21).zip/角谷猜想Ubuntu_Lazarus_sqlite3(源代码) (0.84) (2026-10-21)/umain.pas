unit uMain;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ComCtrls, Math;

type

  { TfrmMain }

  TfrmMain = class(TForm)
    btnRUN: TButton;
    btnRUN1: TButton;
    Button2: TButton;
    Button3: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    EditM: TEdit;
    EditM2: TEdit;
    Label1: TLabel;
    Memo1: TMemo;
    TreeView1: TTreeView;
    procedure btnRUN1Click(Sender: TObject);
    procedure btnRUNClick(Sender: TObject);
  private

  public
    linelist: TStringList;
    rate: double;
    // function GreenBeanGrain(aisGreen, xisBean, bisGrain: integer;
    //  const Green, Bean, Grain: integer): integer;
    function GreenBeanGrain(ID: string; deep, aisGreen, xisBean, bisGrain: longint;
      const Green, Bean, Grain: longint): integer;
    // function GreenBeanGrain(aisGreen, xisBean, bisGrain: int64;  const Green, Bean, Grain: int64): integer;
    function getIntFromByteString(bs: string): integer;
    //将二进制字符串转化为十进制数值
    function getByteStringFromInt(i: integer): string;
    //将十进制数值转化为二进制字符串
    function GreenBeanGrain2(M: longint; ID: string;
      deep, aisGreen, xisBean, bisGrain: longint;
      const Green, Bean, Grain: longint): integer;
  end;

var
  frmMain: TfrmMain;

implementation

{$R *.lfm}

{ TfrmMain }

procedure TfrmMain.btnRUNClick(Sender: TObject);
var
  www: integer;
begin
  self.Memo1.Lines.Clear;
  self.linelist := TStringList.Create;
  rate := 0.0;
  //www := GreenBeanGrain(1, 2, 1, 1, 2, 1, 1);
  //if GreenBeanGrain(2, 1, 1, 2, 1, 1) = 1 then

  // if EditM.Text='' then EditM.Text:='12345';
  www := GreenBeanGrain('1', 1, 2, 1, 1, 2, 1, 1);
  //   www := GreenBeanGrain2(strtoint(ditM.Text),'',1, 2, 1, 1, 2, 1, 1);
  begin
    ShowMessage('ok=' + IntToStr(www));
    application.ProcessMessages;
    self.Memo1.Lines.Assign(self.linelist);
    ShowMessage('Memo=ok=' + IntToStr(linelist.Count));
    application.ProcessMessages; //290,980 // 1,652,927  //306  //256,244 //132,7070
    self.Memo1.Lines.SaveToFile('GreenBeanGrain.txt');
    ShowMessage('txt=ok');
  end;
  linelist.Free;
end;

procedure TfrmMain.btnRUN1Click(Sender: TObject);
var
  www: integer;
  varv: string;
begin
  self.Memo1.Lines.Clear;
  self.linelist := TStringList.Create;
  rate := 0.0;
  //www := GreenBeanGrain(1, 2, 1, 1, 2, 1, 1);
  //if GreenBeanGrain(2, 1, 1, 2, 1, 1) = 1 then

  // if EditM.Text = '' then EditM.Text := '12345';


  // if EditM2.Text <> '' then EditM.Text := IntToStr(getIntFromByteString(EditM2.Text));
  //www := GreenBeanGrain('',1, 2, 1, 1, 2, 1, 1);
  varv := '100111000111011';
  if inputquery('请输入要处理的自然数M：',
    '处理全路径将显示：', varv) then
    EditM.Text := IntToStr(getIntFromByteString(varv));
    EditM2.Text := varv;

  www := GreenBeanGrain2(StrToInt(EditM.Text), '1', 1, 2, 1, 1, 2, 1, 1);
  begin
    ShowMessage('ok=' + IntToStr(www));
    application.ProcessMessages;
    self.Memo1.Lines.Assign(self.linelist);
    ShowMessage('Memo=ok=' + IntToStr(linelist.Count));
    application.ProcessMessages; //290,980 // 1,652,927  //306  //256,244 //132,7070
    self.Memo1.Lines.SaveToFile('GreenBeanGrain.txt');
    ShowMessage('txt=ok');
  end;
  linelist.Free;
end;

//function TfrmMain.GreenBeanGrain(aisGreen, xisBean, bisGrain: int64; const Green, Bean, Grain: int64): integer;
function TfrmMain.GreenBeanGrain(ID: string; deep, aisGreen, xisBean, bisGrain: longint;
  const Green, Bean, Grain: longint): integer;
  //function TfrmMain.GreenBeanGrain(aisGreen, xisBean, bisGrain: integer;
  //  const Green, Bean, Grain: integer): integer;
var
  // a, b, x: int64;
  a, b, x: longint;
  //a, b, x: integer;
  gbg: integer;
  aa: integer;
  one: string;
begin
  gbg := 0;
  deep := deep * 2;
  a := aisGreen;
  x := xisBean;
  b := bisGrain;

  //if a = 536870912 then  //536870912
  //  application.ProcessMessages;
  //if ((a = 256) and (b = 39)) then
  //  application.ProcessMessages;

  aa := 0;
  if gbg = 0 then
  begin
    while (((a mod 2) = 0) and ((b mod 2) = 0)) do
    begin

      if (((a mod 2) = 0) and ((b mod 2) = 0)) then
      begin
        if (((a mod 3) = 0) and ((b mod 3) = 1) and (a >= 3) and (b > 3)) then
        begin
          a := a div 3;
          b := (b - 1) div 3;
          aa := aa + 1;

        end;
        if a < Green then
          gbg := 1
        else if ((a = Green) and (b < Grain)) then
          gbg := 1;
      end;
      if (((a mod 2) = 0) and ((b mod 2) = 0)) then
      begin
        a := a div 2;
        b := b div 2;
      end;
    end;
    if a < Green then
      gbg := 1
    else if ((a = Green) and (b < Grain)) then
      // gbg := 1;
      gbg := 1;
    ////else if (b < Grain) then
    ///    gbg := 1;   //此处断点，一个也没有
  end;
  //////////////////////////////////////
  //if aa = 0  then
  // if gbg = 0 then
  // begin
  //   if (((a mod 2) = 0) and ((b mod 2) = 1)) then
  //   begin
  //     //while (((a mod 3) = 0) and ((b mod 3) = 1) and (a >= 3) and (b > 3)) do
  //     if (((a mod 3) = 0) and ((b mod 3) = 1) and (a >= 3) and (b > 3)) then
  //     begin     //a=18,b=13,     a=6k+4,multi 3 add 1 ,error???
  //       a := a div 3;
  //       b := (b - 1) div 3;
  //       aa := aa + 1;
  //       while (((a mod 2) = 0) and ((b mod 2) = 0)) do
  //       begin
  //         a := a div 2;
  //         b := b div 2;
  //       end;
  //     end;

  //   end;
  //end;


  ////////////////////////////////////

  if aa = 0 then
    if gbg = 0 then
    begin
      while (((a mod 2) = 0) and ((b mod 2) = 1)) do
      begin
        a := a * 3;
        b := b * 3 + 1;

        while (((a mod 2) = 0) and ((b mod 2) = 0)) do
        begin
          a := a div 2;
          b := b div 2;
          if (((a mod 2) = 0) and ((b mod 2) = 0)) then
          begin
            if (((a mod 3) = 0) and ((b mod 3) = 1) and (a >= 3) and (b > 3)) then
            begin
              a := a div 3;
              b := (b - 1) div 3;
              aa := aa + 1;

            end;
            if a < Green then
              gbg := 1
            else if ((a = Green) and (b < Grain)) then
              gbg := 1;
          end;

        end;
        if aa > 0 then break;
      end;
      //if a < 0 then
      //  application.ProcessMessages;
      if a < Green then
        gbg := 1
      else if ((a = Green) and (b < Grain)) then
        gbg := 1;
    end;




  //if 1=0 then
  if gbg = 1 then
  begin
    //if not ((a > 0) and (b>0) and  (Green > 0) and (Grain>0)) then
    if ((a > 0) and (b > 0) and (Green > 0) and (Grain > 0)) then
      //if not ((a > 0) and (b > 0) and (Green > 0) and (Grain > 0)) then
    begin
      // rate:=rate+(1.0/deep);
      rate := rate + (2.0 / deep);
      one := IntToStr(Green) + ' * N' + IntToStr(Bean) + ' + ' +
        IntToStr(Grain) + ' -->  ' + IntToStr(a) + ' * M' + IntToStr(x) +
        ' + ' + IntToStr(b) + ' ok  branID=' + ID + '=' + IntToStr(
        getintFromByteString(ID)) + '  rate=' + floattostr(rate);

      linelist.add(one);
      //self.Memo1.Lines.add(one);
      //application.ProcessMessages;
      //  if linelist.Count>290980 then
      //     application.ProcessMessages;
    end;
  end;
  if gbg = 0 then
    //if not ((a > 0) and (b > 0) and (Green > 0) and (Grain > 0)) then
    if ((a > 0) and (b > 0) and (Green > 0) and (Grain > 0)) then
    begin
      if deep <= trunc(power(2, 49)) then
      begin
        //  gbg := GreenBeanGrain(aisGreen * 2, xisBean + 1, bisGrain, Green *
        //   2, Bean + 1, Grain);
        gbg := GreenBeanGrain('0' + ID, deep, a * 2, x + 1, b, Green *
          2, Bean + 1, Grain);
        //  if  (aisGreen * 2 mod 3)=0 then
        //     application.ProcessMessages;
        //  gbg := gbg * GreenBeanGrain(aisGreen * 2, xisBean + 1, aisGreen +
        //    bisGrain, Green * 2, Bean + 1, Green + Grain);


        gbg := gbg * GreenBeanGrain('1' + ID, deep, a * 2, x + 1, a +
          b, Green * 2, Bean + 1, Green + Grain);
        //if gbg = 0 then
        //  ShowMessage('error');
        //if gbg = 0 then
        //  application.ProcessMessages;

      end;
      if deep = trunc(power(2, 50)) then
      begin
        //gbg := 1;
        gbg := 0;
      end;
    end;

  Result := gbg;
end;

function TfrmMain.getIntFromByteString(bs: string): integer;
var
  i: integer;
  c: char;
begin
  Result := 0;
  // Pascal字符串从下标1开始遍历每一位
  for i := 1 to Length(bs) do
  begin
    c := bs[i];
    // 逐位左移（乘2）加当前位，就是二进制转十进制的原生写法
    Result := Result * 2;
    if c = '1' then
      Result := Result + 1
    else if c <> '0' then
    begin
      // 遇到非0/1字符（非法输入），可以在这里加错误处理，这里默认返回-1标记
      Result := -1;
      Exit;
    end;
  end;
end;

function TfrmMain.getByteStringFromInt(i: integer): string;
begin
  // 边界：0直接返回'0'
  if i = 0 then
  begin
    Result := '0';
    Exit;
  end;

  Result := '';
  // 除2取余，从最低位开始收集
  while i > 0 do
  begin
    if i mod 2 = 1 then
      Result := '1' + Result
    else
      Result := '0' + Result;
    i := i div 2;
  end;
end;


function TfrmMain.GreenBeanGrain2(M: longint; ID: string;
  deep, aisGreen, xisBean, bisGrain: longint;
  const Green, Bean, Grain: longint): integer;
var
  // a, b, x: int64;
  a, b, x, mm: longint;
  //a, b, x: integer;
  gbg: integer;
  aa: integer;
  one: string;
begin
  gbg := 0;
  deep := deep * 2;
  a := aisGreen;
  x := xisBean;
  b := bisGrain;

  //if a = 536870912 then  //536870912
  //  application.ProcessMessages;
  //if ((a = 256) and (b = 39)) then
  //  application.ProcessMessages;

  aa := 0;
  if gbg = 0 then
  begin
    while (((a mod 2) = 0) and ((b mod 2) = 0)) do
    begin

      if (((a mod 2) = 0) and ((b mod 2) = 0)) then
      begin
        if (((a mod 3) = 0) and ((b mod 3) = 1) and (a >= 3) and (b > 3)) then
        begin
          a := a div 3;
          b := (b - 1) div 3;
          aa := aa + 1;
          mm := a + b;
          // if ((mm=M) and (ID>M)) then
          //   showmessage('在这里');
        end;
        if a < Green then
          gbg := 1
        else if ((a = Green) and (b < Grain)) then
          gbg := 1;
      end;
      if (((a mod 2) = 0) and ((b mod 2) = 0)) then
      begin
        a := a div 2;
        b := b div 2;
      end;
    end;
    if a < Green then
      gbg := 1
    else if ((a = Green) and (b < Grain)) then
      // gbg := 1;
      gbg := 1;
    ////else if (b < Grain) then
    ///    gbg := 1;   //此处断点，一个也没有
  end;
  //////////////////////////////////////
  //if aa = 0  then
  // if gbg = 0 then
  // begin
  //   if (((a mod 2) = 0) and ((b mod 2) = 1)) then
  //   begin
  //     //while (((a mod 3) = 0) and ((b mod 3) = 1) and (a >= 3) and (b > 3)) do
  //     if (((a mod 3) = 0) and ((b mod 3) = 1) and (a >= 3) and (b > 3)) then
  //     begin     //a=18,b=13,     a=6k+4,multi 3 add 1 ,error???
  //       a := a div 3;
  //       b := (b - 1) div 3;
  //       aa := aa + 1;
  //       while (((a mod 2) = 0) and ((b mod 2) = 0)) do
  //       begin
  //         a := a div 2;
  //         b := b div 2;
  //       end;
  //     end;

  //   end;
  //end;


  ////////////////////////////////////

  if aa = 0 then
    if gbg = 0 then
    begin
      while (((a mod 2) = 0) and ((b mod 2) = 1)) do
      begin
        a := a * 3;
        b := b * 3 + 1;

        while (((a mod 2) = 0) and ((b mod 2) = 0)) do
        begin
          a := a div 2;
          b := b div 2;
          if (((a mod 2) = 0) and ((b mod 2) = 0)) then
          begin
            if (((a mod 3) = 0) and ((b mod 3) = 1) and (a >= 3) and (b > 3)) then
            begin
              a := a div 3;
              b := (b - 1) div 3;
              aa := aa + 1;

            end;
            if a < Green then
              gbg := 1
            else if ((a = Green) and (b < Grain)) then
              gbg := 1;
          end;

        end;
        if aa > 0 then break;
      end;
      //if a < 0 then
      //  application.ProcessMessages;
      if a < Green then
        gbg := 1
      else if ((a = Green) and (b < Grain)) then
        gbg := 1;
    end;




  // if 1=0 then
  if gbg = 1 then
  begin
    //if not ((a > 0) and (b>0) and  (Green > 0) and (Grain>0)) then
    if ((a > 0) and (b > 0) and (Green > 0) and (Grain > 0)) then
      //if not ((a > 0) and (b > 0) and (Green > 0) and (Grain > 0)) then
    begin
      // rate:=rate+(1.0/deep);
     // rate := rate + (2.0 / deep);
      one := IntToStr(Green) + ' * N' + IntToStr(Bean) + ' + ' +
        IntToStr(Grain) + ' -->  ' + IntToStr(a) + ' * M' + IntToStr(x) +
        ' + ' + IntToStr(b) + ' ok  branID=' + ID + '=' + IntToStr(
        getintFromByteString(ID)) + ' M=' + IntToStr(M) + '=' +
        getByteStringFromint(M) ;//+ '  rate=' + floattostr(rate);
      if getintFromByteString(ID) > M then
        one := one + '   ID=M+' + IntToStr(getintFromByteString(ID) - M);
      linelist.add(one);
      //self.Memo1.Lines.add(one);
      //application.ProcessMessages;
      //  if linelist.Count>290980 then
      //     application.ProcessMessages;
    end;
  end;
  //if getintFromByteString(ID) <= M then
  if gbg = 0 then
    //if not ((a > 0) and (b > 0) and (Green > 0) and (Grain > 0)) then
    if ((a > 0) and (b > 0) and (Green > 0) and (Grain > 0)) then
    begin
      if deep <= trunc(power(2, 49)) then
      begin
        //  gbg := GreenBeanGrain(aisGreen * 2, xisBean + 1, bisGrain, Green *
        //   2, Bean + 1, Grain);
        //rate := rate + (2.0 / deep);
        one := IntToStr(Green) + ' * N' + IntToStr(Bean) + ' + ' +
          IntToStr(Grain) + ' -->  ' + IntToStr(a) + ' * M' + IntToStr(x) +
          ' + ' + IntToStr(b) + '   branID=' + ID + '=' + IntToStr(
          getintFromByteString(ID)) + ' M=' + IntToStr(M) + '=' +
          getByteStringFromint(M);// + '  rate=' + floattostr(rate);
        if getintFromByteString(ID) > M then
          one := one + '   ID=M+' + IntToStr(getintFromByteString(ID) - M);
        linelist.add(one);
        if rightstr(getByteStringFromInt(M), length(ID) + 1) = '0' + ID then
          gbg := GreenBeanGrain2(M, '0' + ID, deep, a * 2, x + 1, b,
            Green * 2, Bean + 1, Grain);
        //  if  (aisGreen * 2 mod 3)=0 then
        //     application.ProcessMessages;
        //  gbg := gbg * GreenBeanGrain(aisGreen * 2, xisBean + 1, aisGreen +
        //    bisGrain, Green * 2, Bean + 1, Green + Grain);

        if rightstr(getByteStringFromInt(M), length(ID) + 1) = '1' + ID then
          gbg := gbg * GreenBeanGrain2(M, '1' + ID, deep, a * 2, x +
            1, a + b, Green * 2, Bean + 1, Green + Grain);
        //if gbg = 0 then
        //  ShowMessage('error');
        //if gbg = 0 then
        //  application.ProcessMessages;

      end;
      if deep = trunc(power(2, 50)) then
      begin
        //gbg := 1;
        gbg := 0;
      end;
    end;

  Result := gbg;
end;

end.
