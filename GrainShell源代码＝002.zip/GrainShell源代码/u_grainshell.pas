unit u_GrainShell;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ComCtrls,math;

type

  { Tfrm_GrainShell }

  Tfrm_GrainShell = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button_LR: TButton;
    Edit1: TEdit;
    Edit_LR: TEdit;
    Memo1: TMemo;
    Memo2: TMemo;
    Memo_LR: TMemo;
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button_LRClick(Sender: TObject);
  private

  public

  end;

var
  frm_GrainShell: Tfrm_GrainShell;

implementation

{$R *.lfm}

{ Tfrm_GrainShell }

procedure Tfrm_GrainShell.Button1Click(Sender: TObject);
var
  i, ii, j, k: integer;
  www: TStringList;
begin
  Memo1.Clear;
  Memo2.Clear;
  application.ProcessMessages;
  www := TStringList.Create;
  www.Add('1');
  www.Add('5');
  k := StrToInt(edit1.Text);
  for i := 1 to k do
  begin
    ii := i;
    // if i = 21 then   //21形成17循环，不是1不是5不是21本身，这种内部检测循环，如何算法？？？
    //  if i = 25 then
    if (i mod 1000 = 0) then
      application.ProcessMessages;
    while (ii mod 2) = 0 do
      ii := ii div 2;
    if (ii mod 2) = 1 then
    begin
      ii := ii * 3 - 1;////
    end;
    while 1 = 1 do
    begin
      while (ii mod 2) = 0 do
        ii := ii div 2;
      if ii = 1 then
      begin
        memo1.Lines.Add(IntToStr(i) + '==1');
        // application.ProcessMessages;
        break;//continue;
      end;
      if ii = 5 then
      begin
        memo1.Lines.Add(IntToStr(i) + '==5');
        //  application.ProcessMessages;
        break;//continue;
      end;
      if ii = i then
      begin
        memo1.Lines.Add(IntToStr(i) + '==' + IntToStr(i));
        www.Add(IntToStr(i));
        // application.ProcessMessages;
        break;//continue;
      end;
      if www.IndexOf(IntToStr(ii)) > 0 then
      begin
        memo1.Lines.Add(IntToStr(i) + '==' + IntToStr(ii));
        //www.Add(inttostr(i));
        //  application.ProcessMessages;
        break;//continue;
      end;
      if (ii mod 2) = 1 then
      begin
        ii := ii * 3 - 1;////
      end;
    end;

  end;
  memo2.Lines.Assign(www);
  //www.free;
end;

procedure Tfrm_GrainShell.Button2Click(Sender: TObject);
var
  i, ii, j, k: int64;  //integer,longint
  www: TStringList;
begin
  Memo1.Clear;
  Memo2.Clear;
  application.ProcessMessages;
  www := TStringList.Create;
  www.Add('1');
  www.Add('5');
  k := StrToInt(edit1.Text);
  for i := 1 to k do
  begin
    ii := i;
    // if i = 21 then   //21形成17循环，不是1不是5不是21本身，这种内部检测循环，如何算法？？？
    //  if i >= 149345 then    //  if i >= 149345 then
    // begin
    // if (i mod 10)=0 then
    //    application.ProcessMessages;
    // end;
    if (i mod 1000 = 0) then
      application.ProcessMessages;
    while (ii mod 2) = 0 do
      ii := ii div 2;
    if (ii mod 2) = 1 then
    begin
      ii := ii * 3 - 1;////
    end;
    while 1 = 1 do
    begin
      while (ii mod 2) = 0 do
        ii := ii div 2;
      if ii = 1 then
      begin
        if (i mod 1000 = 0) then
          memo1.Lines.Add(IntToStr(i) + '==1');
        // application.ProcessMessages;
        break;//continue;
      end;
      if ii = 5 then
      begin
        if (i mod 1000 = 0) then
          memo1.Lines.Add(IntToStr(i) + '==5');
        //  application.ProcessMessages;
        break;//continue;
      end;
      if ii = i then
      begin
        if (i mod 1000 = 0) then
          memo1.Lines.Add(IntToStr(i) + '==' + IntToStr(i));
        www.Add(IntToStr(i));
        // application.ProcessMessages;
        break;//continue;
      end;
      if www.IndexOf(IntToStr(ii)) > 0 then
      begin
        if (i mod 1000 = 0) then
          memo1.Lines.Add(IntToStr(i) + '==' + IntToStr(ii));
        //www.Add(inttostr(i));
        //  application.ProcessMessages;
        break;//continue;
      end;
      if (ii mod 2) = 1 then
      begin
        ii := ii * 3 - 1;////
      end;
    end;

  end;
  memo2.Lines.Assign(www);
  //www.free;
end;

procedure Tfrm_GrainShell.Button_LRClick(Sender: TObject);
var
  i, j, k, n, nn, m,mm,a,b,c: integer;
begin
  n := StrToInt(edit_lr.Text);

  nn := n;
  m := 0;

  while nn > 1 do
  begin
    if (nn mod 2) = 1 then
    begin
      nn := nn * 3 + 1;
    end
    else
    begin
      nn := nn div 2;
      m := m + 1;
    end;
  end;

  c:=trunc(power(2,m));
  a:=n;
  b:=c-a;

  memo_lr.lines.Clear;
  memo_lr.lines.Add('2^'+inttostr(m)+' - '+inttostr(b)+' = '+inttostr(n));

  nn := n;
 // m := 0;
  mm:=0;
  while nn > 1 do
  begin
    if (nn mod 2) = 1 then
    begin
      nn := nn * 3 + 1;
      mm:=mm+1;
      b:=b*3-1;
  memo_lr.lines.Add('3^'+inttostr(mm)+'*2^'+inttostr(m)+' - '+inttostr(b)+' = '+inttostr(nn));
    end
    else
    begin
      nn := nn div 2;
      m := m - 1;
      b:=b div 2;
      memo_lr.lines.Add('3^'+inttostr(mm)+'*2^'+inttostr(m)+' - '+inttostr(b)+' = '+inttostr(nn));
    end;
  end;



end;

end.
